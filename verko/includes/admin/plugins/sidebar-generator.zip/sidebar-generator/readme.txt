= 1.2.1 =
* Fixed duplicating sidebar on wp 2.4.x

= 1.2 =
* Improve the sidebar id for wp 2.4+

= 1.0 =
* Initial Release