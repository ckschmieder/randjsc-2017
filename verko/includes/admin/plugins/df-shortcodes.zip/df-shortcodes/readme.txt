####################### Changelog ######################
Version 1.3.5 March 29th 2016
* Visual composer compatibility 4.11.2

Version 1.3.4 March 29th 2016
* Anchor menu position error for compability on Visual Composer 4.11.1

Version 1.3.3 December 11th 2015
* Compatibility with Visual Composer 4.9

Version 1.3.2 December 2nd 2015
* Compatibility with Visual Composer 4.8.1
* Change style tabs

Version 1.3.1 August 21th 2015
* Fixed: several shortcode not shown
* Compatibility with Visual Composer 4.6.2

Version 1.3 May 28th 2015
* add image icon in service shortcode
* add two layouts in service shortcode (right with icon and right icon)
* Reset Single Image Line Height
* Fixed: anchor id js
* Fixed: advance gmaps js

Version 1.2 May 13th 2015
* Fixed all carousel shortcode

Version 1.1 April 30th 2015
* add compability with visual composer 4.5

Version 1.0 April 29th 2015
* Initial Release
